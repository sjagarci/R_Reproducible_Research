library(tidyverse)

# 1. Reading in data ------------------------------------------------------



# 2. Iteratively performing analyses --------------------------------------



# 3. Summarizing and condensing datasets ----------------------------------



# 4. Splitting into lists and extracting list items -----------------------



# 5. Iterating over multiple vectors or lists -----------------------------



